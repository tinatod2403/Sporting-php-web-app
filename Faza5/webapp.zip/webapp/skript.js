// $(document).ready(function() {

//     function postaviTabeluNovost(){
//         red = $("<tr></tr>");
//         for(let i = 0; i++; i<3){
//             let novi_td = $("<td></td>");
            
//             red.append(novi_td);
//         }
//         $("novosti-tabela").append(red);
//     }
// });

